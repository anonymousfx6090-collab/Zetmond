/**
 * Orchid Ledger system: proof-first financial workspace using paper-white surfaces,
 * aubergine navigation, Zetmond Violet for trusted actions, and visual audit trails.
 */
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { Link, Route, Switch, useLocation, useParams } from "wouter";
import {
  Activity,
  AlertCircle,
  ArrowDownLeft,
  ArrowRight,
  ArrowUpRight,
  Banknote,
  Bell,
  Blocks,
  Check,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  Clock3,
  Copy,
  CreditCard,
  FileClock,
  FileText,
  Fingerprint,
  Gauge,
  Headphones,
  KeyRound,
  Landmark,
  LayoutDashboard,
  LockKeyhole,
  LogOut,
  MapPin,
  Menu,
  MoreHorizontal,
  Network,
  Plus,
  QrCode,
  ReceiptText,
  Search,
  Send,
  Settings,
  ShieldAlert,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Store,
  UserCheck,
  UsersRound,
  Vault,
  WalletCards,
  X,
  Zap,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

const logoUrl = "/images/zetmond-logo.png";
const vaultHeroUrl = "/images/zetmond-vault-hero.png";
const kycUrl = "/images/zetmond-kyc-illustration.png";
const evidenceUrl = "/images/zetmond-vault-evidence.png";

type NavItem = { label: string; href: string; icon: LucideIcon; count?: string };
type WalletTab = "overview" | "activity" | "security";

const customerNav: NavItem[] = [
  { label: "Overview", href: "/", icon: LayoutDashboard },
  { label: "P2P market", href: "/market", icon: Store },
  { label: "Vault", href: "/vault", icon: Vault, count: "1" },
  { label: "Activity", href: "/activity", icon: Activity },
];

const accountNav: NavItem[] = [
  { label: "Security", href: "/security", icon: ShieldCheck },
  { label: "Settings", href: "/settings", icon: Settings },
  { label: "Support", href: "/support", icon: Headphones },
];

const adminNav: NavItem[] = [
  { label: "Operations", href: "/admin", icon: Gauge },
  { label: "KYC queue", href: "/admin/kyc", icon: UserCheck, count: "18" },
  { label: "Trades", href: "/admin/trades", icon: Vault, count: "3" },
  { label: "Compliance", href: "/admin/compliance", icon: ShieldAlert, count: "7" },
  { label: "Event ledger", href: "/admin/events", icon: FileClock },
];

type P2PMarket = "GHS" | "NGN";
type P2POffer = { user: string; initials: string; rate: string; range: string; available: string; completion: string; trades: string; method: string; colour: string };

const p2pMarkets: Record<P2PMarket, { country: string; settlementLabel: string; paymentLabel: string; offers: P2POffer[] }> = {
  GHS: {
    country: "Ghana",
    settlementLabel: "GHS settlement",
    paymentLabel: "GHS settles externally",
    offers: [
      { user: "Akosua Mensah", initials: "AM", rate: "GH₵15.50", range: "GH₵800 — GH₵15,000", available: "4,400 USDT", completion: "99.4%", trades: "145 trades", method: "Mobile money", colour: "bg-violet-100 text-violet-800" },
      { user: "Kwame Owusu", initials: "KO", rate: "GH₵15.56", range: "GH₵500 — GH₵9,000", available: "2,100 USDT", completion: "98.8%", trades: "88 trades", method: "MTN MoMo", colour: "bg-fuchsia-100 text-fuchsia-800" },
      { user: "Esi Addo", initials: "EA", rate: "GH₵15.60", range: "GH₵1,500 — GH₵35,000", available: "8,000 USDT", completion: "100%", trades: "206 trades", method: "Bank transfer", colour: "bg-indigo-100 text-indigo-800" },
    ],
  },
  NGN: {
    country: "Nigeria",
    settlementLabel: "NGN settlement",
    paymentLabel: "NGN settles externally",
    offers: [
      { user: "Ayo Adeyemi", initials: "AA", rate: "₦1,578", range: "₦50,000 — ₦1,800,000", available: "4,400 USDT", completion: "99.4%", trades: "145 trades", method: "Bank transfer", colour: "bg-violet-100 text-violet-800" },
      { user: "Blessing O.", initials: "BO", rate: "₦1,581", range: "₦25,000 — ₦900,000", available: "2,100 USDT", completion: "98.8%", trades: "88 trades", method: "OPay / bank", colour: "bg-fuchsia-100 text-fuchsia-800" },
      { user: "Yusuf Hamid", initials: "YH", rate: "₦1,585", range: "₦100,000 — ₦2,500,000", available: "8,000 USDT", completion: "100%", trades: "206 trades", method: "Bank transfer", colour: "bg-indigo-100 text-indigo-800" },
    ],
  },
};

const vaultSettlements: Record<P2PMarket, { seller: string; rate: string; amount: string; method: string; recipient: string; accountLabel: string; accountValue: string; networkLabel: string; networkValue: string }> = {
  GHS: { seller: "Akosua Mensah", rate: "GH₵15.50", amount: "GH₵2,325.00", method: "MTN Mobile Money", recipient: "Akosua Mensah", accountLabel: "Mobile money no.", accountValue: "024 998 7610", networkLabel: "Network", networkValue: "MTN MoMo" },
  NGN: { seller: "Ayo Adeyemi", rate: "₦1,578", amount: "₦236,700.00", method: "Bank transfer", recipient: "Ayo Adeyemi", accountLabel: "Account number", accountValue: "012 498 7610", networkLabel: "Bank", networkValue: "Access Bank" },
};

const transactionRows = [
  { icon: ArrowDownLeft, title: "USDT deposit", detail: "TRC-20 · 19 confirmations", amount: "+ 250.00 USDT", date: "Today, 09:32", state: "Completed", tone: "success" },
  { icon: Vault, title: "Vault lock", detail: "Trade #ZT-20884 · 150 USDT", amount: "− 150.00 USDT", date: "Today, 09:11", state: "Locked", tone: "violet" },
  { icon: Send, title: "USDT transfer", detail: "TRC-20 · TWma…3XrN", amount: "− 80.00 USDT", date: "Yesterday, 18:04", state: "Completed", tone: "success" },
  { icon: ArrowDownLeft, title: "USDT deposit", detail: "TRC-20 · 19 confirmations", amount: "+ 425.00 USDT", date: "Aug 22, 12:45", state: "Completed", tone: "success" },
];

const localCurrencyViews = {
  GHS: { code: "GHS", country: "Ghana", amount: "GH₵6,975.00", rate: "GH₵15.50 per USDT" },
  NGN: { code: "NGN", country: "Nigeria", amount: "₦702,620.00", rate: "₦1,561.38 per USDT" },
  KES: { code: "KES", country: "Kenya", amount: "KSh58,050.00", rate: "KSh129.00 per USDT" },
  USD: { code: "USD", country: "United States", amount: "$450.00", rate: "$1.00 per USDT" },
} as const;

type LocalCurrencyCode = keyof typeof localCurrencyViews;

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster richColors position="top-right" />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={DashboardPage} />
      <Route path="/market" component={MarketPage} />
      <Route path="/offers/new" component={CreateOfferPage} />
      <Route path="/vault" component={VaultPage} />
      <Route path="/vault/:id" component={VaultPage} />
      <Route path="/send" component={SendPage} />
      <Route path="/receive" component={ReceivePage} />
      <Route path="/activity" component={ActivityPage} />
      <Route path="/security" component={SecurityPage} />
      <Route path="/settings" component={SettingsPage} />
      <Route path="/support" component={SupportPage} />
      <Route path="/admin" component={AdminOverviewPage} />
      <Route path="/admin/kyc" component={AdminKycPage} />
      <Route path="/admin/trades" component={AdminTradesPage} />
      <Route path="/admin/compliance" component={AdminCompliancePage} />
      <Route path="/admin/events" component={AdminEventsPage} />
      <Route component={NotFoundPage} />
    </Switch>
  );
}

function Brand({ light = false }: { light?: boolean }) {
  return (
    <Link href="/" className="brand-mark" aria-label="Zetmond home">
      <img src={logoUrl} alt="" className="h-9 w-9 rounded-xl object-cover" />
      <span className={light ? "text-white" : "text-[#24143b]"}>zetmond</span>
    </Link>
  );
}

function CustomerShell({ children, title, eyebrow, action }: { children: React.ReactNode; title?: string; eyebrow?: string; action?: React.ReactNode }) {
  const [location] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  return (
    <div className="min-h-screen bg-[#f7f5fb] text-[#281b3e] lg:flex">
      <aside className="customer-sidebar">
        <div className="px-5 pt-7"><Brand light /></div>
        <p className="sidebar-caption mt-11 px-5">Wallet</p>
        <nav className="mt-3 space-y-1 px-3">
          {customerNav.map((item) => <SidebarItem item={item} active={location === item.href || (item.href === "/vault" && location.startsWith("/vault"))} key={item.label} />)}
        </nav>
        <p className="sidebar-caption mt-8 px-5">Account</p>
        <nav className="mt-3 space-y-1 px-3">
          {accountNav.map((item) => <SidebarItem item={item} active={location === item.href} key={item.label} />)}
        </nav>
        <div className="sidebar-user mt-auto">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-2xl bg-white/10 text-xs font-bold text-white">CO</div>
            <div className="min-w-0"><p className="truncate text-sm font-bold text-white">Chiamaka Okafor</p><p className="mt-0.5 text-xs text-violet-200">Tier 2 verified</p></div>
            <ChevronDown className="ml-auto h-4 w-4 text-violet-200" />
          </div>
        </div>
      </aside>

      <div className="customer-main">
        <header className="topbar">
          <button className="mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="Open menu">{menuOpen ? <X /> : <Menu />}</button>
          <div className="hidden md:block">{eyebrow && <p className="eyebrow">{eyebrow}</p>}{title && <h1 className="page-title">{title}</h1>}</div>
          <div className="ml-auto flex items-center gap-3">{action}<button className="icon-button relative" onClick={() => toast.info("No new notifications") } aria-label="Notifications"><Bell className="h-5 w-5" /><span className="notification-dot" /></button><button className="avatar-button" onClick={() => toast.info("Profile menu")}>CO</button></div>
        </header>
        {menuOpen && <MobileNav onClose={() => setMenuOpen(false)} />}
        <main className="customer-content">{children}</main>
      </div>
    </div>
  );
}

function SidebarItem({ item, active }: { item: NavItem; active: boolean }) {
  const Icon = item.icon;
  return <Link href={item.href} className={`side-nav-item ${active ? "side-nav-active" : ""}`}><Icon className="h-[18px] w-[18px]" /><span>{item.label}</span>{item.count && <span className="side-count">{item.count}</span>}</Link>;
}

function MobileNav({ onClose }: { onClose: () => void }) {
  return <div className="mobile-nav"><div className="mb-5"><Brand /></div>{[...customerNav, ...accountNav].map((item) => <Link onClick={onClose} href={item.href} key={item.label} className="mobile-nav-link"><item.icon className="h-5 w-5" />{item.label}<ChevronRight className="ml-auto h-4 w-4" /></Link>)}</div>;
}

function DashboardPage() {
  const [displayCurrency, setDisplayCurrency] = useState<LocalCurrencyCode>("GHS");
  const [currencyMenuOpen, setCurrencyMenuOpen] = useState(false);
  const suggestedCurrency: LocalCurrencyCode = "GHS";
  const currentLocalView = localCurrencyViews[displayCurrency];
  const isLocationSuggested = displayCurrency === suggestedCurrency;
  return <CustomerShell action={<Link href="/receive" className="top-action"><QrCode className="h-4 w-4" />Receive USDT</Link>}>
    <div className="dashboard-head"><div><p className="eyebrow">Tuesday, 26 August</p><h1 className="page-title md:hidden">Your wallet</h1><h2 className="display-title hidden md:block">Your USDT, clearly accounted for.</h2></div><div className="secure-label"><ShieldCheck className="h-4 w-4" />USDT custody secured</div></div>
    <section className="wallet-hero">
      <div className="relative z-10 max-w-md"><p className="wallet-label">Available custody balance</p><div className="balance-line">450.00<small> USDT</small></div><p className="mt-2 text-sm text-violet-100">Indicative local value · <span className="font-semibold text-white">{currentLocalView.amount}</span></p><div className="mt-7 flex flex-wrap gap-3"><Link href="/receive" className="hero-button hero-button-light"><ArrowDownLeft className="h-4 w-4" />Receive USDT</Link><Link href="/send" className="hero-button hero-button-dark"><Send className="h-4 w-4" />Send USDT</Link></div></div>
      <div className="relative z-10 mt-6 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.14em] text-violet-200"><span>USDT custody account</span><span className="h-1 w-1 rounded-full bg-violet-300" /><span>Ref. WAL-79D4</span><span className="h-1 w-1 rounded-full bg-violet-300" /><span>09:32 WAT</span></div>
      <img src={vaultHeroUrl} alt="Abstract Zetmond vault" className="wallet-hero-image" />
      <div className="wallet-hero-orbit orbit-one" /><div className="wallet-hero-orbit orbit-two" />
    </section>
    <section className="mt-6 grid gap-5 xl:grid-cols-[1.35fr_.65fr]">
      <div className="grid gap-5 md:grid-cols-2"><AssetCard asset="Tether" code="USDT" amount="450.00" note="Available to send or lock in Vault" icon={<span className="font-bold">₮</span>} color="usdt" change="+0.8%" /><div className="asset-card"><div className="flex items-start justify-between"><div className="asset-icon asset-ngn"><Banknote className="h-5 w-5" /></div><div className="relative"><button className="location-currency-control" onClick={() => setCurrencyMenuOpen(!currencyMenuOpen)}><MapPin className="h-3.5 w-3.5" /><span>{currentLocalView.code}</span><ChevronDown className="h-3.5 w-3.5" /></button>{currencyMenuOpen && <div className="currency-menu">{(Object.keys(localCurrencyViews) as LocalCurrencyCode[]).map((code) => <button key={code} className={code === displayCurrency ? "selected" : ""} onClick={() => { setDisplayCurrency(code); setCurrencyMenuOpen(false); }}><span>{code}</span><small>{localCurrencyViews[code].country}</small>{code === suggestedCurrency && <em>Suggested</em>}</button>)}</div>}</div></div><div className="mt-7"><p className="text-sm font-semibold text-[#5d526e]">Indicative local value <span className="ml-1 text-xs font-bold text-[#9d93aa]">{currentLocalView.code}</span></p><p className="mt-2 text-2xl font-bold tracking-tight text-[#281b3e] tabular-nums">{currentLocalView.amount}</p><p className="mt-2 text-xs font-medium text-[#93899f]">{isLocationSuggested ? `Suggested from your location · ${currentLocalView.country}` : `Manual display preference · ${currentLocalView.country}`}</p><p className="mt-1 text-xs font-medium text-[#93899f]">Not a wallet balance · {currentLocalView.rate}</p></div><div className="ledger-strip mt-5"><span>{isLocationSuggested ? "Country suggestion" : "Display preference"}</span><span className="dot-divider" /><span>Indicative</span><span className="dot-divider" /><span>09:32</span></div></div></div>
      <div className="quick-panel"><p className="card-kicker">Quick actions</p><div className="mt-4 grid grid-cols-4 gap-2"><QuickAction href="/send" icon={Send} label="Send" /><QuickAction href="/receive" icon={QrCode} label="Receive" /><QuickAction href="/market" icon={Store} label="P2P trade" /><QuickAction href="/activity" icon={ReceiptText} label="Activity" /></div></div>
    </section>
    <section className="mt-6 grid gap-6 xl:grid-cols-[1.22fr_.78fr]">
      <div className="paper-card overflow-hidden"><div className="card-heading"><div><p className="card-kicker">Wallet activity</p><h3>Recent movements</h3></div><Link href="/activity" className="text-link">View all <ArrowRight className="h-4 w-4" /></Link></div><div className="divide-y divide-[#eeeaf5]">{transactionRows.slice(0, 3).map((row) => <TransactionRow row={row} key={row.title} />)}</div></div>
      <Link href="/vault" className="vault-spotlight"><div className="vault-spotlight-top"><div className="grid h-10 w-10 place-items-center rounded-2xl bg-white/15"><Vault className="h-5 w-5" /></div><span className="status-text state-warning"><Clock3 className="h-3.5 w-3.5" />09:48 left</span></div><p className="mt-8 text-xs font-bold uppercase tracking-[.16em] text-violet-200">Vault trade #ZT-20884</p><h3 className="mt-2 text-2xl font-bold tracking-tight">150 USDT is protected.</h3><p className="mt-3 text-sm leading-6 text-violet-100">Payment proof is being independently verified before release.</p><div className="mt-6 flex items-center justify-between border-t border-white/15 pt-4 text-sm font-semibold"><span>View Vault record</span><ArrowRight className="h-5 w-5" /></div></Link>
    </section>
  </CustomerShell>;
}

function AssetCard({ asset, code, amount, note, icon, color, change }: { asset: string; code: string; amount: string; note: string; icon: React.ReactNode; color: string; change: string }) {
  return <div className="asset-card"><div className="flex items-start justify-between"><div className={`asset-icon asset-${color}`}>{icon}</div><span className="trend-text"><Sparkles className="h-3 w-3" />{change}</span></div><div className="mt-7"><p className="text-sm font-semibold text-[#5d526e]">{asset} <span className="ml-1 text-xs font-bold text-[#9d93aa]">{code}</span></p><p className="mt-2 text-2xl font-bold tracking-tight text-[#281b3e] tabular-nums">{amount} {code === "USDT" && <span className="text-base font-semibold text-[#877c91]">USDT</span>}</p><p className="mt-2 text-xs font-medium text-[#93899f]">{note}</p></div><div className="ledger-strip mt-5"><span>Custody ledger</span><span className="dot-divider" /><span>Ref. AS-8841</span><span className="dot-divider" /><span>09:32</span></div></div>;
}

function QuickAction({ href, icon: Icon, label }: { href: string; icon: LucideIcon; label: string }) {
  return <Link href={href} className="quick-action"><span><Icon className="h-4 w-4" /></span><small>{label}</small></Link>;
}

function TransactionRow({ row }: { row: typeof transactionRows[number] }) {
  const Icon = row.icon;
  return <div className="transaction-row"><div className={`transaction-icon transaction-${row.tone}`}><Icon className="h-4 w-4" /></div><div className="min-w-0"><p className="truncate font-semibold text-[#392d4d]">{row.title}</p><p className="mt-0.5 truncate text-xs text-[#93899f]">{row.detail}</p></div><div className="ml-auto text-right"><p className={`font-bold tabular-nums ${row.amount.startsWith("+") ? "text-emerald-600" : "text-[#392d4d]"}`}>{row.amount}</p><p className="mt-0.5 text-xs text-[#93899f]">{row.date}</p></div><span className={`record-state record-${row.tone}`}>{row.state}</span></div>;
}

function MarketPage() {
  const [side, setSide] = useState<"buy" | "sell">("buy");
  const [market, setMarket] = useState<P2PMarket>("GHS");
  const marketView = p2pMarkets[market];
  return <CustomerShell title="P2P market" eyebrow={`Trade USDT / ${market}`} action={<Link href="/offers/new" className="top-action"><Plus className="h-4 w-4" />Create offer</Link>}>
    <div className="market-banner"><div className="relative z-10 max-w-xl"><p className="eyebrow text-violet-200">Zetmond P2P · {marketView.country}</p><h2 className="display-title mt-2 text-white">Trade USDT with a visible trail.</h2><p className="mt-3 max-w-lg text-sm leading-6 text-violet-100">The Vault holds USDT only. {market} is the external settlement currency and payment evidence is verified before USDT can move.</p></div><div className="market-banner-proof"><LockKeyhole className="h-6 w-6" /><span>USDT escrow</span><small>{marketView.paymentLabel}</small></div></div>
    <div className="mt-6 flex flex-col justify-between gap-4 lg:flex-row lg:items-center"><div className="segmented-control"><button className={side === "buy" ? "selected" : ""} onClick={() => setSide("buy")}>Buy USDT</button><button className={side === "sell" ? "selected" : ""} onClick={() => setSide("sell")}>Sell USDT</button></div><div className="filter-row"><div className="market-switcher"><button className={market === "GHS" ? "active" : ""} onClick={() => setMarket("GHS")}>GHS · Ghana</button><button className={market === "NGN" ? "active" : ""} onClick={() => setMarket("NGN")}>NGN · Nigeria</button></div><button className="filter-button"><SlidersHorizontal className="h-4 w-4" />Filters</button></div></div>
    <div className="mt-5 overflow-hidden rounded-[20px] bg-white shadow-[0_10px_38px_rgba(40,27,62,.06)]"><div className="offer-table-head"><span>Trader</span><span>Price</span><span>Limits</span><span>Payment</span><span /></div>{marketView.offers.map((offer) => <OfferRow offer={offer} key={offer.user} side={side} market={market} />)}</div>
    <div className="mt-6 grid gap-5 md:grid-cols-3"><TrustNote icon={ShieldCheck} title="USDT locks first" text="Seller funds are reserved before payment details appear." /><TrustNote icon={Fingerprint} title="Payment is checked" text="A button click never triggers a fund release." /><TrustNote icon={FileText} title="Evidence is retained" text="State changes and sources remain attached to the trade." /></div>
  </CustomerShell>;
}

function OfferRow({ offer, side, market }: { offer: P2POffer; side: "buy" | "sell"; market: P2PMarket }) {
  return <div className="offer-row"><div className="flex min-w-0 items-center gap-3"><span className={`grid h-10 w-10 shrink-0 place-items-center rounded-2xl text-xs font-bold ${offer.colour}`}>{offer.initials}</span><div className="min-w-0"><p className="truncate font-bold text-[#392d4d]">{offer.user} <Check className="ml-1 inline h-3.5 w-3.5 text-[#5e35f2]" /></p><p className="mt-0.5 text-xs text-[#91869d]">{offer.completion} · {offer.trades} · Vault eligible</p></div></div><div><p className="font-bold tabular-nums text-[#392d4d]">{offer.rate}</p><p className="mt-0.5 text-xs text-[#91869d]">rate source: seller offer</p></div><div><p className="text-sm font-semibold text-[#392d4d]">{offer.range}</p><p className="mt-0.5 text-xs text-[#91869d]">{offer.available} available</p></div><span className="meta-label">{offer.method}</span><Link href={`/vault/${market}`} className="offer-cta">{side === "buy" ? "Buy" : "Sell"}<ArrowRight className="h-4 w-4" /></Link></div>;
}

function TrustNote({ icon: Icon, title, text }: { icon: LucideIcon; title: string; text: string }) { return <div className="trust-note"><Icon className="h-5 w-5 text-[#5e35f2]" /><div><p className="font-bold text-[#392d4d]">{title}</p><p className="mt-1 text-xs leading-5 text-[#897d93]">{text}</p></div></div>; }

function CreateOfferPage() {
  const [side, setSide] = useState<"Sell USDT" | "Buy USDT">("Sell USDT");
  return <CustomerShell title="Create an offer" eyebrow="P2P market"><div className="form-page"><div className="form-main"><div className="paper-card p-6 sm:p-8"><p className="card-kicker">Offer direction</p><div className="segmented-control mt-4 w-full"><button className={side === "Sell USDT" ? "selected" : ""} onClick={() => setSide("Sell USDT")}>Sell USDT</button><button className={side === "Buy USDT" ? "selected" : ""} onClick={() => setSide("Buy USDT")}>Buy USDT</button></div><div className="form-grid mt-8"><Field label="Custody asset"><div className="select-surface"><span className="grid h-7 w-7 place-items-center rounded-lg bg-[#5e35f2] text-sm font-bold text-white">₮</span>USDT<ChevronDown className="ml-auto h-4 w-4" /></div></Field><Field label="P2P settlement currency"><div className="select-surface"><span className="grid h-7 w-7 place-items-center rounded-lg bg-emerald-50 text-xs font-bold text-emerald-700">GH₵</span>GHS<ChevronDown className="ml-auto h-4 w-4" /></div></Field><Field label="Your rate (GHS)"><InputValue prefix="GH₵" value="15.50" /></Field><Field label="Available USDT"><InputValue value="500.00" suffix="USDT" /></Field><Field label="Minimum settlement"><InputValue prefix="GH₵" value="800" /></Field><Field label="Maximum settlement"><InputValue prefix="GH₵" value="15,000" /></Field></div><div className="mt-7"><Field label="External payment method"><div className="select-surface"><Landmark className="h-4 w-4 text-[#5e35f2]" />MTN Mobile Money<ChevronDown className="ml-auto h-4 w-4" /></div></Field></div><div className="mt-8 flex justify-end gap-3"><Link href="/market" className="secondary-button">Cancel</Link><button className="primary-button" onClick={() => toast.success("Offer draft saved in this UI prototype")}>Review offer <ArrowRight className="h-4 w-4" /></button></div></div></div><aside className="form-aside"><img src={evidenceUrl} alt="Escrow evidence illustration" /><p className="card-kicker mt-4">Vault safeguard</p><h3>Only USDT enters the Vault.</h3><p>When a buyer accepts, the seller’s USDT is locked. GHS payment happens externally and release requires independent confirmation.</p><div className="ledger-strip mt-5"><span>USDT custody</span><span className="dot-divider" /><span>External GHS payment</span></div></aside></div></CustomerShell>;
}

function Field({ label, children }: { label: string; children: React.ReactNode }) { return <label className="field"><span>{label}</span>{children}</label>; }
function InputValue({ prefix, value, suffix }: { prefix?: string; value: string; suffix?: string }) { return <div className="input-surface"><span className="text-[#776b82]">{prefix}</span><span className="font-semibold text-[#392d4d]">{value}</span><span className="ml-auto text-xs font-bold text-[#9a8fa5]">{suffix}</span></div>; }

function VaultPage() {
  const params = useParams<{ id?: string }>();
  const market: P2PMarket = params.id === "NGN" ? "NGN" : "GHS";
  const settlement = vaultSettlements[market];
  const [seconds, setSeconds] = useState(588);
  useEffect(() => { const timer = window.setInterval(() => setSeconds((value) => Math.max(value - 1, 0)), 1000); return () => window.clearInterval(timer); }, []);
  const minutes = String(Math.floor(seconds / 60)).padStart(2, "0"); const remaining = String(seconds % 60).padStart(2, "0");
  const steps = [
    { title: "Seller funds locked", time: "09:11:04", detail: "150.00 USDT moved to Vault", state: "done" },
    { title: "Payment instructions revealed", time: "09:11:08", detail: "Buyer payment window opened", state: "done" },
    { title: "Awaiting buyer payment", time: "Now", detail: "Verified payment event is required", state: "current" },
    { title: "Release to buyer", time: "Pending", detail: "Available after verification", state: "future" },
  ];
  return <CustomerShell title="Vault trade" eyebrow="P2P / Trade #ZT-20884" action={<button className="top-action" onClick={() => toast.info("A dispute requires supporting evidence")}>Report an issue</button>}>
    <div className="vault-page-head"><div><div className="flex items-center gap-3"><h2 className="display-title">150.00 USDT</h2><span className="status-text state-active">{market} payment pending</span></div><p className="mt-2 text-sm text-[#81758d]">You are buying USDT from {settlement.seller} at {settlement.rate} per USDT. {market} remains an external settlement amount.</p></div><div className="countdown-card"><span><Clock3 className="h-4 w-4" />Payment window</span><strong>{minutes}:{remaining}</strong></div></div>
    <div className="vault-layout mt-6"><section className="space-y-6"><div className="paper-card p-6 sm:p-7"><div className="card-heading"><div><p className="card-kicker">Vault state</p><h3>Proof before release</h3></div><div className="status-orbit"><LockKeyhole className="h-4 w-4" /></div></div><div className="vault-steps mt-7">{steps.map((step, index) => <div className="vault-step" key={step.title}><div className={`step-node ${step.state}`}>{step.state === "done" ? <Check className="h-3.5 w-3.5" /> : index + 1}</div>{index < steps.length - 1 && <div className={`step-line ${step.state === "done" ? "filled" : ""}`} />}<div className="min-w-0 pb-6"><div className="flex items-center justify-between gap-4"><p className="font-bold text-[#392d4d]">{step.title}</p><span className="text-xs font-semibold text-[#958a9f]">{step.time}</span></div><p className="mt-1 text-sm text-[#887c93]">{step.detail}</p></div></div>)}</div></div>
      <div className="paper-card p-6 sm:p-7"><div className="flex items-start justify-between gap-5"><div><p className="card-kicker">External payment instruction</p><h3 className="mt-1">Send exactly {settlement.amount}</h3></div><span className="meta-label">{settlement.method}</span></div><div className="bank-details"><div><span>Recipient</span><strong>{settlement.recipient}</strong></div><div><span>{settlement.accountLabel}</span><strong>{settlement.accountValue}</strong></div><div><span>{settlement.networkLabel}</span><strong>{settlement.networkValue}</strong></div></div><div className="instruction-callout"><AlertCircle className="h-4 w-4" /><p>{market} payment occurs outside Zetmond. A manual “I paid” confirmation does not release the USDT.</p></div><div className="mt-5 flex flex-wrap gap-3"><button className="primary-button" onClick={() => toast.info("Zetmond will wait for the independently confirmed payment event")}>I have made payment</button><button className="secondary-button" onClick={() => toast.info("Share only the trade reference: ZT-20884")}>Share reference <Copy className="h-4 w-4" /></button></div></div></section>
      <aside className="space-y-6"><div className="evidence-card"><img src={evidenceUrl} alt="Abstract escrow verification" /><div className="relative z-10 px-5 pb-5"><p className="card-kicker">Confirmation source</p><h3 className="mt-1">No payment detected yet.</h3><p className="mt-2 text-sm leading-6 text-[#786c85]">Zetmond will reconcile a signed provider event against this exact external settlement amount.</p><div className="evidence-label"><span className="pulse-dot" />Listening for payment provider event</div></div></div><div className="paper-card p-5"><p className="card-kicker">Trade record</p><div className="record-list mt-4"><div><span>Settlement market</span><b>{market}</b></div><div><span>Seller</span><b>{settlement.seller}</b></div><div><span>Rate</span><b>{settlement.rate} / USDT</b></div><div><span>Vault ref</span><b>VLT-8AF19C</b></div></div><button className="text-link mt-5" onClick={() => toast.info("All state events are visible in the production audit trail")}>View confirmation history <ArrowRight className="h-4 w-4" /></button></div></aside>
    </div>
  </CustomerShell>;
}

function MoneyPage({ mode }: { mode: "send" | "receive" }) {
  const copy = {
    send: { eyebrow: "Transfer USDT", title: "Send USDT", hint: "Use a confirmed TRC-20 address only.", icon: Send },
    receive: { eyebrow: "Fund USDT custody", title: "Receive USDT", hint: "Only send USDT via the TRC-20 network.", icon: QrCode },
  }[mode];
  const Icon = copy.icon;
  return <CustomerShell title={copy.title} eyebrow={copy.eyebrow}><div className="money-page"><div className="money-main"><div className="paper-card p-6 sm:p-8"><div className="money-icon"><Icon className="h-6 w-6" /></div><h2 className="display-title mt-6">{copy.title}</h2><p className="mt-2 text-sm leading-6 text-[#82768d]">{copy.hint}</p>{mode === "send" && <><div className="mt-7"><Field label="Recipient TRC-20 address"><div className="input-surface text-sm text-[#8c8097]">TQv3...paste or scan address</div></Field></div><div className="mt-5"><Field label="USDT amount"><InputValue value="50.00" suffix="USDT" /></Field></div></>}{mode === "receive" && <div className="receive-block mt-7"><div className="qr-panel"><QrCode className="h-28 w-28" /></div><p className="mt-5 text-xs font-bold uppercase tracking-[.14em] text-[#93879f]">Your USDT TRC-20 address</p><p className="mt-2 break-all font-mono text-sm font-bold text-[#443857]">TRVeG5Jd5DqH7HCrPQj94rL2rA38dPoN3L</p><button className="secondary-button mt-5" onClick={() => toast.success("Address copied")}>Copy address <Copy className="h-4 w-4" /></button></div>}<div className="mt-8 flex justify-end"><button className="primary-button" onClick={() => toast.info("This control is a UI-only prototype")}>{mode === "receive" ? "I understand" : "Continue"}<ArrowRight className="h-4 w-4" /></button></div></div></div><aside className="money-aside"><p className="card-kicker">USDT-only custody</p><h3>Confirm the network.</h3><p>Zetmond demonstrates USDT transfers only. Network and address validation must happen on a secure backend before any balance movement. Local-currency values are reference displays, not transferable wallet funds.</p><div className="ledger-strip mt-5"><span>TRC-20 required</span><span className="dot-divider" /><span>UI prototype</span></div></aside></div></CustomerShell>;
}

function SendPage() { return <MoneyPage mode="send" />; }
function ReceivePage() { return <MoneyPage mode="receive" />; }

function ActivityPage() { return <CustomerShell title="Activity" eyebrow="Wallet ledger"><div className="flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><h2 className="display-title">Everything leaves a record.</h2><p className="mt-2 text-sm text-[#81758d]">Your funds, trades and confirmation events, in one readable history.</p></div><div className="filter-row"><button className="filter-button"><SlidersHorizontal className="h-4 w-4" />All activity</button><button className="filter-button">This month <ChevronDown className="h-4 w-4" /></button></div></div><div className="paper-card mt-6 overflow-hidden"><div className="ledger-head"><span>Movement</span><span>Reference</span><span>Amount</span><span>Status</span></div>{transactionRows.map((row) => <div className="ledger-row" key={row.title}><div className="flex items-center gap-3"><div className={`transaction-icon transaction-${row.tone}`}><row.icon className="h-4 w-4" /></div><div><b>{row.title}</b><p>{row.date}</p></div></div><p className="font-mono text-xs font-semibold text-[#756983]">{row.detail}</p><b className={row.amount.startsWith("+") ? "text-emerald-600" : "text-[#392d4d]"}>{row.amount}</b><span className={`record-state record-${row.tone}`}>{row.state}</span></div>)}</div></CustomerShell>; }

function SecurityPage() { return <CustomerShell title="Security" eyebrow="Account protection"><div className="security-grid"><section className="paper-card p-6 sm:p-8"><p className="card-kicker">Verification</p><div className="mt-3 flex flex-col gap-5 md:flex-row md:items-center"><img src={kycUrl} alt="Identity verification illustration" className="h-36 w-full rounded-2xl object-cover md:w-48" /><div><h2 className="display-title text-3xl">Identity verified.</h2><p className="mt-2 text-sm leading-6 text-[#82768d]">Your Tier 2 wallet is active. Your details are protected and your verification history stays attached to your account.</p><button className="text-link mt-4" onClick={() => toast.info("KYC information would appear here")}>View verification record <ArrowRight className="h-4 w-4" /></button></div></div><div className="ledger-strip mt-6 border-t border-[#eeeaf5] pt-4"><span>Source: KYC review</span><span className="dot-divider" /><span>Ref. KYC-004721</span><span className="dot-divider" /><span>Verified Aug 22</span></div></section><section className="paper-card p-6"><p className="card-kicker">Account controls</p><div className="settings-list mt-4"><SettingLine icon={KeyRound} title="Two-step verification" detail="Authenticator app enabled" action="Manage" /><SettingLine icon={Fingerprint} title="Trusted devices" detail="2 active sessions" action="Review" /><SettingLine icon={Bell} title="Security alerts" detail="Email and push notifications" action="Edit" /></div></section></div><section className="paper-card mt-6 p-6 sm:p-7"><div className="card-heading"><div><p className="card-kicker">Active devices</p><h3>Sessions with access</h3></div><button className="secondary-button" onClick={() => toast.info("Other sessions would be revoked")}>Sign out other devices</button></div><div className="device-row"><div className="device-icon"><Network className="h-5 w-5" /></div><div><b>Chrome on macOS</b><p>Lagos, Nigeria · Current session</p></div><span className="record-state record-success">Current</span></div><div className="device-row"><div className="device-icon"><SmartPhoneProxy /></div><div><b>Zetmond Mobile</b><p>Lagos, Nigeria · Active 2 hours ago</p></div><button className="text-link" onClick={() => toast.info("Session management is a prototype")}>Manage</button></div><div className="ledger-strip mt-3 border-t border-[#eeeaf5] pt-4"><span>Last session audit</span><span className="dot-divider" /><span>SEC-70F3</span><span className="dot-divider" /><span>09:28 WAT</span></div></section></CustomerShell>; }

function SmartPhoneProxy() { return <Blocks className="h-5 w-5" />; }
function SettingLine({ icon: Icon, title, detail, action }: { icon: LucideIcon; title: string; detail: string; action: string }) { return <div className="setting-line"><span className="setting-icon"><Icon className="h-4 w-4" /></span><div><b>{title}</b><p>{detail}</p></div><button className="text-link ml-auto" onClick={() => toast.info(`${title} management is a UI placeholder`)}>{action}</button></div>; }

function SettingsPage() { return <CustomerShell title="Settings" eyebrow="Account preferences"><div className="settings-page"><section className="paper-card p-6"><p className="card-kicker">Profile</p><div className="settings-list mt-3"><SettingLine icon={UsersRound} title="Personal details" detail="Chiamaka Okafor · Ghana" action="Edit" /><SettingLine icon={MapPin} title="Local display currency" detail="GHS suggested from your location · can be changed anytime" action="Manage" /><SettingLine icon={Landmark} title="P2P payment methods" detail="External local settlement preferences" action="Manage" /><SettingLine icon={Bell} title="Notifications" detail="Trade and security alerts enabled" action="Configure" /></div></section><section className="paper-card p-6"><p className="card-kicker">Legal and help</p><div className="settings-list mt-3"><SettingLine icon={FileText} title="Terms of service" detail="Version 1.0 draft" action="Read" /><SettingLine icon={ShieldCheck} title="Privacy notice" detail="How Zetmond processes account data" action="Read" /><SettingLine icon={CircleHelp} title="Dispute policy" detail="Escalation and evidence requirements" action="Read" /></div></section></div></CustomerShell>; }

function SupportPage() { return <CustomerShell title="Support" eyebrow="Help centre"><div className="support-hero"><div><p className="eyebrow text-violet-200">Proof-first support</p><h2 className="display-title mt-2 text-white">We start with the record.</h2><p className="mt-3 max-w-xl text-sm leading-6 text-violet-100">Find guidance for USDT custody, TRC-20 transfers, local-value displays, Vault trades and account protection.</p></div><Search className="h-16 w-16 text-violet-200/50" /></div><div className="mt-6 grid gap-5 md:grid-cols-3"><SupportCard icon={Vault} title="Vault & disputes" text="Understand payment windows, evidence, trade state and escalation." /><SupportCard icon={WalletCards} title="USDT movements" text="TRC-20 deposits, sends, confirmations and transaction records." /><SupportCard icon={Banknote} title="Local-value display" text="GHS, NGN and other local reference values are not wallet balances." /></div><div className="paper-card mt-6 p-6"><p className="card-kicker">Need more help?</p><h3 className="mt-1">Open a support case with the right evidence.</h3><p className="mt-2 max-w-xl text-sm leading-6 text-[#80748c]">In a production system, support requests are protected and linked to only the wallet or trade records that are relevant to the case.</p><button className="primary-button mt-5" onClick={() => toast.info("Support case submission is a UI placeholder")}>Contact support <ArrowRight className="h-4 w-4" /></button></div></CustomerShell>; }
function SupportCard({ icon: Icon, title, text }: { icon: LucideIcon; title: string; text: string }) { return <button className="support-card" onClick={() => toast.info(`${title} guide is coming soon`)}><span><Icon className="h-5 w-5" /></span><h3>{title}</h3><p>{text}</p><ArrowRight className="mt-5 h-4 w-4" /></button>; }

function AdminShell({ children, title, eyebrow }: { children: React.ReactNode; title: string; eyebrow: string }) {
  const [location] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  return <div className="min-h-screen bg-[#f4f2f8] text-[#281b3e] lg:flex"><aside className="admin-sidebar"><div className="px-5 pt-7"><Brand light /></div><div className="admin-product-mark"><span><Gauge className="h-4 w-4" />Operations workspace</span><small>Restricted access</small></div><nav className="space-y-1 px-3">{adminNav.map((item) => <SidebarItem key={item.label} item={item} active={location === item.href} />)}</nav><div className="mt-auto border-t border-white/10 p-4"><div className="flex items-center gap-3"><div className="grid h-9 w-9 place-items-center rounded-xl bg-white/10 text-xs font-bold text-white">AM</div><div><p className="text-sm font-bold text-white">A. Mensah</p><p className="text-xs text-violet-200">Compliance admin</p></div><button className="ml-auto text-violet-200" onClick={() => toast.info("Sign out") }><LogOut className="h-4 w-4" /></button></div></div></aside><div className="customer-main"><header className="topbar"><button className="mobile-menu" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</button><div><p className="eyebrow">{eyebrow}</p><h1 className="page-title">{title}</h1></div><div className="ml-auto flex items-center gap-3"><div className="system-label"><span className="pulse-dot" />All systems observed</div><button className="icon-button"><Bell className="h-5 w-5" /><span className="notification-dot" /></button></div></header>{menuOpen && <div className="mobile-nav"><div className="mb-5"><Brand /></div>{adminNav.map((item) => <Link href={item.href} key={item.label} onClick={() => setMenuOpen(false)} className="mobile-nav-link"><item.icon className="h-5 w-5" />{item.label}</Link>)}</div>}<main className="customer-content">{children}</main></div></div>;
}

function AdminOverviewPage() { const metrics = [{ label: "Verification queue", value: "18", caption: "6 require human review", icon: UserCheck, color: "violet" }, { label: "Open Vault states", value: "31", caption: "3 nearing expiry", icon: Vault, color: "orange" }, { label: "Compliance alerts", value: "7", caption: "2 high priority", icon: ShieldAlert, color: "red" }, { label: "Settlement exceptions", value: "2", caption: "No balance adjustments", icon: AlertCircle, color: "blue" }]; return <AdminShell title="Operations overview" eyebrow="Zetmond control room"><div className="admin-intro"><div><h2 className="display-title">Nothing moves unseen.</h2><p>Monitor exception queues, escrow states, and the evidence that supports each decision.</p></div><button className="secondary-button" onClick={() => toast.info("Report export is a UI placeholder")}><FileText className="h-4 w-4" />Export report</button></div><div className="metric-grid mt-6">{metrics.map((metric) => <AdminMetric key={metric.label} {...metric} />)}</div><div className="mt-6 grid gap-6 xl:grid-cols-[1.12fr_.88fr]"><section className="paper-card overflow-hidden"><div className="card-heading px-6 pt-6"><div><p className="card-kicker">Priority work</p><h3>Review queue</h3></div><Link href="/admin/kyc" className="text-link">See all <ArrowRight className="h-4 w-4" /></Link></div><AdminQueueRow initials="JS" title="KYC identity mismatch" detail="James Samuel · Automated doc check failed" severity="High" time="4m ago" /><AdminQueueRow initials="ZT" title="Trade payment not matched" detail="ZT-20884 · Awaiting signed provider event" severity="Medium" time="8m ago" /><AdminQueueRow initials="OR" title="USDT transfer velocity threshold" detail="Oluchi R. · 4 USDT send requests in 1 hour" severity="High" time="19m ago" /></section><section className="admin-evidence-panel"><p className="card-kicker text-violet-200">Ledger health</p><h3>Reconciliation is on track.</h3><p>Provider events, internal ledger records, and Vault transitions are in their normal review windows.</p><div className="health-bar"><span style={{ width: "86%" }} /></div><div className="mt-5 grid grid-cols-2 gap-4 border-t border-white/10 pt-5"><div><small>Last event</small><b>09:32:14 WAT</b></div><div><small>Event latency</small><b>1.8 seconds</b></div></div><Link href="/admin/events" className="admin-evidence-link">Inspect event ledger <ArrowRight className="h-4 w-4" /></Link></section></div></AdminShell>; }

function AdminMetric({ label, value, caption, icon: Icon, color }: { label: string; value: string; caption: string; icon: LucideIcon; color: string }) { return <div className="admin-metric"><div className={`admin-metric-icon metric-${color}`}><Icon className="h-5 w-5" /></div><p>{label}</p><h3>{value}</h3><small>{caption}</small><div className="ledger-strip mt-4 border-t border-[#eeeaf5] pt-3"><span>Queue source</span><span className="dot-divider" /><span>Live</span></div></div>; }
function AdminQueueRow({ initials, title, detail, severity, time }: { initials: string; title: string; detail: string; severity: string; time: string }) { return <div className="admin-queue-row"><span className="grid h-9 w-9 place-items-center rounded-xl bg-violet-100 text-xs font-bold text-[#5e35f2]">{initials}</span><div className="min-w-0"><b>{title}</b><p>{detail}</p></div><span className={`risk-label risk-${severity.toLowerCase()}`}>{severity}</span><small>{time}</small><button className="icon-button"><ChevronRight className="h-4 w-4" /></button></div>; }

const kycCases = [{ name: "James Samuel", ref: "KYC-004812", issue: "Document and selfie similarity below threshold", tier: "Tier 2", time: "4 mins ago", risk: "High" }, { name: "Mariam Bello", ref: "KYC-004807", issue: "BVN verification provider timed out", tier: "Tier 1", time: "18 mins ago", risk: "Medium" }, { name: "Chukwuemeka N.", ref: "KYC-004801", issue: "Address document needs refreshed capture", tier: "Tier 2", time: "31 mins ago", risk: "Low" }];
function AdminKycPage() { return <AdminShell title="KYC review queue" eyebrow="Identity & eligibility"><div className="admin-intro"><div><h2 className="display-title">Review, do not override.</h2><p>Identity decisions require a complete evidence record and retain the reviewing administrator.</p></div><button className="filter-button"><SlidersHorizontal className="h-4 w-4" />Priority filter</button></div><div className="paper-card mt-6 overflow-hidden"><div className="kyc-table-head"><span>Applicant</span><span>Review trigger</span><span>Wallet tier</span><span>Priority</span><span /></div>{kycCases.map((item) => <div className="kyc-row" key={item.ref}><div><b>{item.name}</b><p>{item.ref} · Submitted {item.time}</p></div><p>{item.issue}</p><span className="meta-label">{item.tier}</span><span className={`risk-label risk-${item.risk.toLowerCase()}`}>{item.risk}</span><button className="offer-cta" onClick={() => toast.info(`Opened review ${item.ref}`)}>Review <ChevronRight className="h-4 w-4" /></button></div>)}</div></AdminShell>; }

function AdminTradesPage() { return <AdminShell title="Trade monitor" eyebrow="P2P & Vault oversight"><div className="admin-intro"><div><h2 className="display-title">The escrow path, exposed.</h2><p>Inspect payment evidence, state transition history, and dispute eligibility without bypassing the Vault state machine.</p></div><button className="filter-button"><Search className="h-4 w-4" />Find trade</button></div><div className="trade-investigator mt-6"><section className="paper-card p-6 sm:p-7"><div className="card-heading"><div><p className="card-kicker">Trade #ZT-20884</p><h3>Awaiting buyer payment</h3></div><span className="status-text state-active">09:48 left</span></div><div className="investigator-amount"><span>150.00 USDT</span><ArrowRight className="h-5 w-5" /><span>₦236,700.00</span></div><div className="compact-steps"><div className="complete"><Check className="h-4 w-4" /><span>Locked</span></div><div className="complete"><Check className="h-4 w-4" /><span>Instructions</span></div><div className="current"><Clock3 className="h-4 w-4" /><span>Payment event</span></div><div><LockKeyhole className="h-4 w-4" /><span>Release</span></div></div><div className="investigator-action"><p>Payment release is prohibited until a matching signed event is recorded.</p><button className="secondary-button" onClick={() => toast.info("Vault state inspection opened")}>Inspect state transition <ArrowRight className="h-4 w-4" /></button></div></section><aside className="paper-card p-6"><p className="card-kicker">Evidence stream</p><div className="evidence-stream mt-5"><EvidenceLine icon={Vault} time="09:11:04" text="Seller USDT lock ledger posted" done /><EvidenceLine icon={Landmark} time="09:11:08" text="Payment details encrypted and revealed" done /><EvidenceLine icon={Clock3} time="Now" text="Waiting for signed Paystack event" /><EvidenceLine icon={ShieldAlert} time="Pending" text="Dispute pathway remains available" /></div></aside></div><div className="paper-card mt-6 p-6"><div className="card-heading"><div><p className="card-kicker">Other open trades</p><h3>State distribution</h3></div><button className="text-link" onClick={() => toast.info("Trade list view")}>View all trades <ArrowRight className="h-4 w-4" /></button></div><div className="state-stats"><StateStat state="Funds locked" count="12" color="violet" /><StateStat state="Payment detected" count="4" color="blue" /><StateStat state="Disputed" count="3" color="red" /><StateStat state="Expiry window" count="12" color="orange" /></div></div></AdminShell>; }
function EvidenceLine({ icon: Icon, time, text, done }: { icon: LucideIcon; time: string; text: string; done?: boolean }) { return <div className="evidence-line"><span className={done ? "done" : ""}><Icon className="h-4 w-4" /></span><div><b>{text}</b><p>{time}</p></div></div>; }
function StateStat({ state, count, color }: { state: string; count: string; color: string }) { return <div className="state-stat"><span className={`stat-dot stat-${color}`} /><p>{state}</p><b>{count}</b></div>; }

function AdminCompliancePage() { const alerts = [{ title: "Withdrawal velocity threshold", actor: "Oluchi R. · User ID U-10222", context: "4 NGN withdrawal attempts in 63 minutes", priority: "High", score: "82" }, { title: "P2P cancellation pattern", actor: "Abdullah M. · User ID U-10904", context: "5 expired trades in 24 hours", priority: "Medium", score: "61" }, { title: "New device and address change", actor: "Rukayat J. · User ID U-10613", context: "Security control review required", priority: "High", score: "77" }]; return <AdminShell title="Compliance monitor" eyebrow="AML & transaction monitoring"><div className="admin-intro"><div><h2 className="display-title">Alerts need a decision trail.</h2><p>Use evidence and controlled dispositions; never resolve an alert by directly editing account balances.</p></div><div className="system-label"><span className="pulse-dot" />7 alerts open</div></div><div className="compliance-list mt-6">{alerts.map((alert) => <div className="compliance-alert" key={alert.title}><div className="risk-score"><span>{alert.score}</span><small>risk</small></div><div><div className="flex items-center gap-3"><h3>{alert.title}</h3><span className={`risk-label risk-${alert.priority.toLowerCase()}`}>{alert.priority}</span></div><p>{alert.actor}</p><small>{alert.context}</small></div><div className="ml-auto flex items-center gap-3"><button className="secondary-button" onClick={() => toast.info("Evidence review opened")}>Review</button><button className="icon-button"><MoreHorizontal className="h-5 w-5" /></button></div></div>)}</div></AdminShell>; }

function AdminEventsPage() { const events = useMemo(() => [{ event: "provider.payment.confirmed", id: "evt_pstk_99142", source: "Paystack webhook", time: "09:32:14.923", result: "Processed" }, { event: "vault.state.transition", id: "vlt_8AF19C_02", source: "Vault engine", time: "09:11:08.014", result: "Recorded" }, { event: "chain.deposit.confirmed", id: "trc_8f22a1", source: "TRC-20 monitor", time: "08:48:03.221", result: "Credited" }, { event: "kyc.provider.review", id: "kyc_004812", source: "Identity provider", time: "08:31:47.806", result: "Manual review" }], []); return <AdminShell title="Event ledger" eyebrow="Integration & audit trail"><div className="event-hero"><div><p className="eyebrow text-violet-200">Immutable event view</p><h2 className="display-title mt-2 text-white">Every external signal has context.</h2><p className="mt-3 max-w-2xl text-sm leading-6 text-violet-100">Raw event preservation, processing result, and internal reference should remain connected for reconciliation and incident review.</p></div><FileClock className="h-16 w-16 text-violet-200/50" /></div><div className="paper-card mt-6 overflow-hidden"><div className="event-table-head"><span>Event</span><span>Source</span><span>Received WAT</span><span>Result</span></div>{events.map((event) => <div className="event-row" key={event.id}><div><b>{event.event}</b><p>{event.id}</p></div><span className="meta-label">{event.source}</span><span className="font-mono text-xs font-semibold text-[#756983]">{event.time}</span><span className={event.result === "Manual review" ? "record-state record-orange" : "record-state record-success"}>{event.result}</span></div>)}</div></AdminShell>; }

function NotFoundPage() { return <CustomerShell title="Page not found" eyebrow="Navigation"><div className="empty-state"><p className="eyebrow">404</p><h2 className="display-title">This record does not exist.</h2><p>Return to your wallet workspace to continue.</p><Link href="/" className="primary-button mt-5">Back to overview <ArrowRight className="h-4 w-4" /></Link></div></CustomerShell>; }

export default App;
