# Zetmond Wallet System

This folder is a **self-contained frontend prototype**. It bundles the Zetmond visual assets locally so the interface renders correctly when you run it on your own computer.

## Run locally

Install a current Node.js release, then open a terminal in this folder and run:

```bash
pnpm install
pnpm dev
```

Open the localhost address printed in your terminal, typically `http://localhost:3000`.

## Local images

All required brand and interface images live in `client/public/images/`. They are referenced using browser-safe paths such as `/images/zetmond-vault-hero.png`, so they work in a standard local Vite server rather than relying on managed hosting URLs.

## Prototype note

This is a frontend-only product prototype. It illustrates USDT-only custody, local-value display preferences, P2P currency switching, and the Vault workflow. It does not perform real IP lookup, price retrieval, payments, wallet custody, blockchain activity, or financial settlement.
